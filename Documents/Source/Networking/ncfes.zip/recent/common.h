#include <P18F252.h>
#include <DataLib.h>

#define IP1		192
#define	IP2		168
#define	IP3		1
#define	IP4		2

#define	LOWPORT		1
#define HIGHPORT	65536

#define	LEDPORT		PORTD
#define LEDBIT		4

